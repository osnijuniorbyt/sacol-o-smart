# Memory: design/sunset-theme
Updated: now

Tema visual "Pôr do Sol" aplicado em todo o sistema. Cores principais: gradientes de creme claro (#F9F6F0) no topo transitando para dourado quente (#E8C170) e âmbar (#D4A050) na base. Bordas metálicas douradas com efeito shimmer usando tons hsl(40-45, 70-85%, 55-70%). A logo na página de login possui fundo com gradiente de pôr do sol integrado à imagem. A sidebar interna utiliza container da logo com gradiente claro (creme → dourado) ao invés do fundo escuro anterior. Faixas laterais decorativas na página de login seguem o mesmo gradiente vertical de pôr do sol. Fundo principal do app usa tons quentes hsl(38-42, 30-40%, 90-95%). Este tema harmoniza com a identidade verde/laranja da marca, trazendo sofisticação e calor visual.
